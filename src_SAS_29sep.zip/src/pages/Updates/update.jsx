import React from 'react'

function update() {
  return (
    <div>update</div>
  )
}

export default update