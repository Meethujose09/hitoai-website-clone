import React from 'react'

export default function service() {
  return (
    <div><h1>Our Partners</h1>
    
    
    
    </div>
  )
}
